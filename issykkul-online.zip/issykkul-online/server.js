// Иссык-Куль Рейсинг — онлайн-сервер (без зависимостей, нужен только Node.js 18+)
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORT = process.env.PORT || 3000, MAX = 3, PUB = path.join(__dirname, 'public');
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.ico': 'image/x-icon' };
const rooms = new Map(); // имя -> { members: Map(id -> сокет), locked: bool }

// ---------- обычный HTTP: отдаём игру ----------
const server = http.createServer((req, res) => {
  const url = req.url.split('?')[0];
  if (url === '/healthz') { res.end('ok'); return; }
  const file = path.normalize(path.join(PUB, url === '/' ? 'index.html' : url));
  if (!file.startsWith(PUB)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (e, d) => {
    if (e) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
    res.end(d);
  });
});

// ---------- минимальный WebSocket (RFC 6455) ----------
function frame(op, payload) {
  const p = Buffer.from(payload), n = p.length; let h;
  if (n < 126) h = Buffer.from([0x80 | op, n]);
  else { h = Buffer.alloc(4); h[0] = 0x80 | op; h[1] = 126; h.writeUInt16BE(n, 2); }
  return Buffer.concat([h, p]);
}
const sendJ = (s, o) => { if (!s.destroyed && s.writable) s.write(frame(1, JSON.stringify(o))); };

server.on('upgrade', (req, sock) => {
  if (req.url !== '/ws' || !req.headers['sec-websocket-key']) { sock.destroy(); return; }
  const acc = crypto.createHash('sha1').update(req.headers['sec-websocket-key'] + GUID).digest('base64');
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + acc + '\r\n\r\n');
  sock.id = crypto.randomBytes(6).toString('hex'); sock.room = null; sock.pres = {}; sock.alive = true;
  sock.buf = Buffer.alloc(0); let cnt = 0, tick = Date.now();
  sock.on('data', d => {
    sock.buf = Buffer.concat([sock.buf, d]);
    if (sock.buf.length > 16384) { sock.destroy(); return; }
    for (;;) {
      const b = sock.buf; if (b.length < 2) break;
      const op = b[0] & 15; let len = b[1] & 127, off = 2;
      if (!(b[1] & 128)) { sock.destroy(); return; }
      if (len === 126) { if (b.length < 4) break; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { sock.destroy(); return; }
      if (b.length < off + 4 + len) break;
      const mask = b.subarray(off, off + 4), data = Buffer.from(b.subarray(off + 4, off + 4 + len));
      for (let i = 0; i < len; i++) data[i] ^= mask[i & 3];
      sock.buf = b.subarray(off + 4 + len);
      if (op === 8) { sock.end(frame(8, '')); return; }
      if (op === 9) sock.write(frame(10, data));
      else if (op === 10) sock.alive = true;
      else if (op === 1) {
        const now = Date.now(); if (now - tick > 1000) { tick = now; cnt = 0; }
        if (++cnt > 80) continue; // защита от флуда
        let m; try { m = JSON.parse(data.toString()); } catch (e) { continue; }
        onMsg(sock, m);
      }
    }
  });
  sock.on('close', () => leave(sock));
  sock.on('error', () => sock.destroy());
});

// ---------- логика комнат ----------
const err = (s, msg) => sendJ(s, { t: 'err', msg });
function bc(r, from, o) { r.members.forEach(s => { if (s !== from) sendJ(s, o); }); }

function join(s, m) {
  leave(s);
  const name = String(m.room || '');
  if (!/^[a-z0-9_-]{1,40}$/.test(name)) return err(s, 'Неверный код');
  let r = rooms.get(name);
  if (!r) {
    if (!m.create) return err(s, 'Комната не найдена. Проверь код');
    r = { members: new Map(), locked: false }; rooms.set(name, r);
  } else {
    if (m.create) return err(s, 'Код занят, попробуй ещё раз');
    if (r.locked) return err(s, 'Код уже использован: гонка началась');   // одноразовый код
    if (r.members.size >= MAX) return err(s, 'Комната заполнена (3/3)');
  }
  const peers = [...r.members.values()].map(x => ({ peer: x.id, presence: x.pres }));
  r.members.set(s.id, s); s.room = name; s.pres = {};
  sendJ(s, { t: 'joined', id: s.id, peers });
  bc(r, s, { t: 'pj', peer: s.id, presence: {} });
}

function pres(s, patch) {
  const r = rooms.get(s.room); if (!r || !patch || typeof patch !== 'object') return;
  const clean = {};
  Object.keys(patch).slice(0, 24).forEach(k => {
    const v = patch[k];
    if (!/^[A-Za-z_][A-Za-z0-9_]{0,15}$/.test(k)) return;
    if (v === null || typeof v === 'number' || typeof v === 'boolean') clean[k] = v;
    else if (typeof v === 'string') clean[k] = v.slice(0, 24);
  });
  const np = { ...s.pres };
  for (const k in clean) { if (clean[k] === null) delete np[k]; else np[k] = clean[k]; }
  s.pres = np;
  if (clean.lock === 1) r.locked = true;                                  // код сгорает при старте гонки
  bc(r, s, { t: 'pp', peer: s.id, patch: clean });
}

function leave(s) {
  const r = s.room && rooms.get(s.room); if (!r) { s.room = null; return; }
  r.members.delete(s.id); s.room = null;
  bc(r, s, { t: 'pl', peer: s.id });
  if (!r.members.size) rooms.delete([...rooms.entries()].find(e => e[1] === r)[0]); // пустая комната = код сгорел
}

function onMsg(s, m) {
  if (m.t === 'join') join(s, m);
  else if (m.t === 'pres') pres(s, m.patch);
  else if (m.t === 'leave') leave(s);
}

// пинги, чтобы соединение не рвалось на хостинге
const live = new Set();
server.on('upgrade', (req, sock) => { live.add(sock); sock.on('close', () => live.delete(sock)); });
setInterval(() => live.forEach(s => { if (!s.alive) return s.destroy(); s.alive = false; if (s.writable) s.write(frame(9, '')); }), 25000).unref();

if (require.main === module) server.listen(PORT, () => console.log('Игра запущена: http://localhost:' + PORT));
module.exports = server;
